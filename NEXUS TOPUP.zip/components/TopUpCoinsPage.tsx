

import React, { useState, useEffect } from 'react';
import { CoinBalance, CoinPackage, PaymentMethod, PaymentCategory } from '../types.ts';
import { ChevronLeftIcon, ChatBubbleLeftEllipsisIcon, NexusCoinLogoIcon, CheckIcon, ChevronDownIcon } from './icons/index.tsx';
import CheckoutActionBar from './CheckoutActionBar.tsx';

interface TopUpCoinsPageProps {
    balance: CoinBalance;
    packages: CoinPackage[];
    paymentCategories: PaymentCategory[];
    onBack: () => void;
    onPurchase: (pkg: CoinPackage, total: number) => void;
}

const TopUpCoinsPage: React.FC<TopUpCoinsPageProps> = ({ balance, packages, paymentCategories, onBack, onPurchase }) => {
    const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(null);
    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod | null>(null);
    const [openCategory, setOpenCategory] = useState<string | null>('ewallet');
    
    const summary = React.useMemo(() => {
        if (!selectedPackage) {
            return { price: 0, adminFee: 0, total: 0, amount: 0, pkg: null };
        }
        
        const adminFee = selectedPaymentMethod
            ? selectedPaymentMethod.fee.flat + Math.round(selectedPackage.price * (selectedPaymentMethod.fee.percent / 100))
            : 0;
            
        const total = selectedPackage.price + adminFee;
        
        return {
            price: selectedPackage.price,
            adminFee,
            total,
            amount: selectedPackage.amount,
            pkg: selectedPackage
        };
    }, [selectedPackage, selectedPaymentMethod]);

    const handlePackageSelect = (pkg: CoinPackage) => {
        setSelectedPackage(pkg);
    };

    const handlePurchaseClick = () => {
        if (summary.pkg && selectedPaymentMethod) {
            onPurchase(summary.pkg, summary.total);
        }
    };

    return (
        <div className="pt-16 md:pt-20 bg-gray-900 min-h-screen">
            <header className="fixed top-0 left-0 right-0 z-50 bg-gray-800 h-16 md:h-20 border-b border-gray-700">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-full relative">
                    <button onClick={onBack} className="absolute left-4 p-2 rounded-full hover:bg-gray-700">
                        <ChevronLeftIcon className="w-6 h-6 text-white" />
                    </button>
                    <h1 className="text-xl font-bold text-white text-center w-full">Beli Nexus Coins</h1>
                    <div className="absolute right-4">
                        <button className="p-2 rounded-full hover:bg-gray-700">
                            <ChatBubbleLeftEllipsisIcon className="w-6 h-6 text-white" />
                        </button>
                    </div>
                </div>
            </header>
            <main className="max-w-xl mx-auto p-4 space-y-4 pb-44">
                {/* Disclaimer */}
                <div className="text-center text-xs text-yellow-300 p-3 bg-yellow-900/50 border border-yellow-700 rounded-lg">
                    <b>Penting:</b> Nexus Coins adalah poin loyalitas internal, tidak dapat diuangkan, dan hanya berlaku untuk transaksi di aplikasi NexusTOPUP.
                </div>
                
                {/* Current Balance */}
                <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 text-center">
                    <p className="text-sm text-gray-400">Saldo Nexus Coins Kamu</p>
                    <p className="text-2xl font-bold text-white my-1">{balance.available.toLocaleString('id-ID')} NX</p>
                </div>

                {/* Packages */}
                <section>
                    <h2 className="text-lg font-bold text-white mb-3">Pilih Paket Cepat</h2>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {packages.map(pkg => {
                            const isSelected = selectedPackage?.id === pkg.id;
                            return (
                                <button
                                    key={pkg.id}
                                    onClick={() => handlePackageSelect(pkg)}
                                    className={`relative text-left p-3 border-2 rounded-xl transition-all ${isSelected ? 'border-[#7F1DFF] bg-purple-900/50' : 'border-gray-700 bg-gray-800 hover:border-gray-500'}`}
                                >
                                    {pkg.label && (
                                        <div className={`absolute -top-2.5 right-3 text-xs font-bold px-2 py-0.5 rounded-full text-white ${pkg.label === 'Populer' ? 'bg-[#7F1DFF]' : 'bg-orange-500'}`}>
                                            {pkg.label}
                                        </div>
                                    )}
                                    {isSelected && (
                                        <div className="absolute top-2 left-2 w-5 h-5 bg-[#7F1DFF] rounded-full flex items-center justify-center text-white">
                                            <CheckIcon className="w-3.5 h-3.5" />
                                        </div>
                                    )}
                                    <div className="flex items-center space-x-2">
                                        <NexusCoinLogoIcon className="h-[60px] w-auto" />
                                        <p className="font-extrabold text-lg text-white">{pkg.amount.toLocaleString('id-ID')}</p>
                                    </div>
                                    <p className="text-sm text-gray-400 mt-1">Rp{pkg.price.toLocaleString('id-ID')}</p>
                                </button>
                            );
                        })}
                    </div>
                </section>

                 {/* Payment Method */}
                <section>
                    <h2 className="text-lg font-bold text-white mb-3">Pilih Metode Pembayaran</h2>
                    <div className="bg-gray-800 border border-gray-700 rounded-xl p-2 space-y-1">
                        {paymentCategories.map(category => {
                            const isOpen = openCategory === category.id;
                            return (
                                <div key={category.id}>
                                    <button
                                        onClick={() => setOpenCategory(isOpen ? null : category.id)}
                                        className="w-full flex items-center justify-between p-3 hover:bg-gray-700 rounded-lg"
                                    >
                                        <span className="font-bold text-white text-base">{category.name}</span>
                                        <ChevronDownIcon className={`w-5 h-5 text-white transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                                    </button>
                                    {isOpen && (
                                        <div className="pl-3 pr-3 pb-2 space-y-2">
                                            {category.methods.map(method => {
                                                const isSelected = selectedPaymentMethod?.id === method.id;
                                                return (
                                                    <button
                                                        key={method.id}
                                                        onClick={() => setSelectedPaymentMethod(method)}
                                                        className={`w-full flex items-center justify-between p-3 border-2 rounded-lg transition-all ${isSelected ? 'border-[#7F1DFF] bg-purple-900/50' : 'border-transparent bg-gray-700 hover:bg-gray-600'}`}
                                                    >
                                                        <div className="flex items-center space-x-3">
                                                            <method.icon className="w-6 h-6 text-white" />
                                                            <span className="font-semibold text-sm text-white">{method.name}</span>
                                                        </div>
                                                        <div className="flex items-center space-x-3">
                                                          <span className="text-xs text-gray-400 font-semibold">
                                                              Biaya: {
                                                                  method.fee.flat > 0 && method.fee.percent > 0
                                                                  ? `Rp${method.fee.flat.toLocaleString('id-ID')} + ${method.fee.percent}%`
                                                                  : method.fee.flat > 0
                                                                  ? `Rp${method.fee.flat.toLocaleString('id-ID')}`
                                                                  : method.fee.percent > 0
                                                                  ? `${method.fee.percent}%`
                                                                  : 'Gratis'
                                                              }
                                                          </span>
                                                          <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? 'border-[#7F1DFF] bg-[#7F1DFF]' : 'border-gray-500'}`}>
                                                              {isSelected && <CheckIcon className="w-3 h-3 text-white" />}
                                                          </div>
                                                        </div>
                                                    </button>
                                                )
                                            })}
                                        </div>
                                    )}
                                </div>
                            )
                        })}
                    </div>
                </section>
                
                 {/* Summary */}
                <section>
                    <h2 className="text-lg font-bold text-white mb-3">Ringkasan Pembelian</h2>
                    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                            <span className="text-gray-400">Jumlah Coins</span>
                            <span className="font-medium text-white">{summary.amount > 0 ? `${summary.amount.toLocaleString('id-ID')} NX` : '-'}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-400">Harga</span>
                            <span className="font-medium text-white">Rp{summary.price.toLocaleString('id-ID')}</span>
                        </div>
                         <div className="flex justify-between">
                            <span className="text-gray-400">Biaya Admin</span>
                            <span className="font-medium text-white">Rp{summary.adminFee.toLocaleString('id-ID')}</span>
                        </div>
                         <div className="flex justify-between">
                            <span className="text-gray-400">Metode Pembayaran</span>
                            <span className="font-medium text-white">{selectedPaymentMethod ? selectedPaymentMethod.name : '-'}</span>
                        </div>
                        <div className="pt-2 border-t mt-2 flex justify-between items-center border-gray-700">
                            <span className="font-bold text-white">Total Bayar</span>
                            <span className="font-extrabold text-xl text-[#7F1DFF]">Rp{summary.total.toLocaleString('id-ID')}</span>
                        </div>
                    </div>
                </section>
            </main>
            
            <CheckoutActionBar 
                total={summary.total}
                buttonText="Beli Coins Sekarang"
                onClick={handlePurchaseClick}
                disabled={!summary.pkg || !selectedPaymentMethod}
                showBottomNavBar={true}
            />
        </div>
    );
};

export default TopUpCoinsPage;