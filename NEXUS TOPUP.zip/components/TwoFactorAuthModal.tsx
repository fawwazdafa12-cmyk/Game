import React, { useState, useEffect } from 'react';
import { XMarkIcon, ShieldCheckIcon, ClipboardDocumentIcon, ExclamationTriangleIcon } from './icons/index.tsx';

interface TwoFactorAuthModalProps {
    onClose: () => void;
    onEnable: () => void;
    showToast: (message: string, type: 'success' | 'error') => void;
}

const mockRecoveryCodes = [
    'a1b2-c3d4-e5f6-g7h8', 'i9j0-k1l2-m3n4-o5p6',
    'q7r8-s9t0-u1v2-w3x4', 'y5z6-a7b8-c9d0-e1f2',
    'g3h4-i5j6-k7l8-m9n0', 'o1p2-q3r4-s5t6-u7v8'
];
const mockSecret = "JBSWY3DPEHPK3PXP";
const mockQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=otpauth://totp/NexusTOPUP:admin@nexustopup.com?secret=${mockSecret}&issuer=NexusTOPUP&bgcolor=111827&color=ffffff&qzone=1`;

const TwoFactorAuthModal: React.FC<TwoFactorAuthModalProps> = ({ onClose, onEnable, showToast }) => {
    const [isClosing, setIsClosing] = useState(false);
    const [step, setStep] = useState(1);
    const [verificationCode, setVerificationCode] = useState('');

    const handleClose = () => {
        setIsClosing(true);
        setTimeout(onClose, 250);
    };

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') handleClose();
        };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, []);

    const handleVerify = () => {
        // Mock verification - any 6-digit code works for demo
        if (/^\d{6}$/.test(verificationCode)) {
            setStep(2); // Move to recovery codes
        } else {
            showToast('Kode verifikasi harus 6 digit angka.', 'error');
        }
    };
    
    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        showToast('Tersalin ke clipboard!', 'success');
    };

    const StepIndicator = ({ currentStep }: { currentStep: number }) => (
        <div className="flex justify-center space-x-2">
            {[1, 2].map(s => (
                <div key={s} className={`w-2 h-2 rounded-full transition-all ${s === currentStep ? 'bg-white w-4' : 'bg-gray-500'}`}></div>
            ))}
        </div>
    );
    
    const renderStepContent = () => {
        switch (step) {
            case 1: // Scan & Verify
                return (
                    <div className="text-center space-y-4">
                         <h3 className="text-lg font-bold text-white">Aktifkan Autentikasi Dua Faktor</h3>
                         <p className="text-sm text-gray-400">Pindai kode QR ini dengan aplikasi autentikator (Google Authenticator, Authy, dll), lalu masukkan kode 6-digit di bawah.</p>
                         <div className="p-4 bg-white rounded-xl inline-block">
                            <img src={mockQrUrl} alt="QR Code 2FA" className="w-40 h-40"/>
                         </div>
                         <p className="text-xs text-gray-400">Atau masukkan kunci ini secara manual:</p>
                         <div className="flex items-center justify-center space-x-2 p-2 bg-gray-700 rounded-lg">
                            <span className="font-mono text-sm text-white">{mockSecret}</span>
                            <button onClick={() => copyToClipboard(mockSecret)}><ClipboardDocumentIcon className="w-5 h-5 text-gray-300 hover:text-white"/></button>
                         </div>
                         <input 
                            type="text" 
                            inputMode="numeric"
                            value={verificationCode}
                            onChange={e => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0,6))}
                            placeholder="_ _ _   _ _ _"
                            className="w-48 h-14 text-center text-3xl tracking-[0.5em] font-mono bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-[#38BDF8] focus:outline-none"
                        />
                         <button onClick={handleVerify} className="w-full h-12 font-bold bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] text-white rounded-full hover:brightness-110 transition-all">Verifikasi & Aktifkan</button>
                    </div>
                );
            case 2: // Recovery Codes
                return (
                     <div className="text-center space-y-4">
                         <h3 className="text-lg font-bold text-white">Simpan Kode Pemulihan Anda!</h3>
                         <div className="p-3 bg-yellow-900/50 border border-yellow-700 text-yellow-300 rounded-lg text-sm flex items-start space-x-2">
                            <ExclamationTriangleIcon className="w-8 h-8 flex-shrink-0"/>
                            <span>Simpan kode ini di tempat yang aman. Kode ini adalah satu-satunya cara untuk mengakses akun Anda jika kehilangan akses ke aplikasi autentikator.</span>
                         </div>
                         <div className="grid grid-cols-2 gap-3 font-mono text-white text-sm">
                            {mockRecoveryCodes.map(code => (
                                <div key={code} className="p-2 bg-gray-700 rounded-md">{code}</div>
                            ))}
                         </div>
                         <button onClick={() => copyToClipboard(mockRecoveryCodes.join('\n'))} className="w-full h-12 font-bold bg-gray-600 text-white rounded-full hover:bg-gray-500 transition-all">Salin Kode</button>
                         <button onClick={onEnable} className="w-full h-12 font-bold bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] text-white rounded-full hover:brightness-110 transition-all">Selesai, Saya Sudah Simpan</button>
                    </div>
                );
        }
    }

    return (
        <div className="fixed inset-0 z-[100] flex items-end justify-center" role="dialog" aria-modal="true">
            <div 
                className={`fixed inset-0 bg-black/60 transition-opacity duration-300 ${isClosing ? 'opacity-0' : 'opacity-100'}`} 
                onClick={handleClose}
            ></div>
            <div className={`bg-gray-800 w-full max-w-md shadow-lg transition-transform duration-250 ease-out ${isClosing ? 'translate-y-full' : 'translate-y-0'} md:rounded-t-3xl`}>
                <div className="p-6 space-y-5">
                    <div className="flex items-center justify-between pb-4 border-b border-gray-700">
                        <div className="flex items-center space-x-2">
                           <ShieldCheckIcon className="w-6 h-6 text-green-400" />
                           <h2 className="text-xl font-bold text-white">Keamanan Akun</h2>
                        </div>
                        <button onClick={handleClose} aria-label="Tutup" className="text-white hover:opacity-70">
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <StepIndicator currentStep={step} />
                    {renderStepContent()}
                </div>
            </div>
        </div>
    );
};

export default TwoFactorAuthModal;
