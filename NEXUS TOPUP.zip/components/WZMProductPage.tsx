
import React, { useState } from "react";
import { CheckoutData, PaymentCategory, ProductDetail } from "../types";
import { ChevronLeftIcon, ShareIcon, ChatBubbleLeftEllipsisIcon, StarIcon, ChevronDownIcon } from "./icons";
import { warzoneProductPageBannerUrl, mlProductPageBannerUrl } from "./ImageAssets";
import { formatDateOnlyShort } from "../src/lib/time";

interface WZMProductPageProps {
  product: ProductDetail;
  paymentCategories: PaymentCategory[];
  onProceedToCheckout: (data: CheckoutData) => void;
  showToast: (message: string, type: "success" | "error") => void;
  onBack: () => void;
}

const APP_NAME = "NexusTOPUP";
const TABBAR_H = 72;

// Activision ID (UID) WZM: hanya angka 6–16 digit
const RE_WZM_UID = /^\d{6,16}$/;

function currency(n: number) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
}

export default function WZMProductPage({
  product,
  paymentCategories,
  onProceedToCheckout,
  showToast,
  onBack,
}: WZMProductPageProps) {
  const [tab, setTab] = useState<"trx" | "info">("trx");
  const [uid, setUid] = useState("");                 // Activision ID (UID)
  const [nickname, setNickname] = useState("");       // opsional (untuk verifikasi tampilan)
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const [qty, setQty] = useState(1);
  const [email, setEmail] = useState("");
  const [wa, setWa] = useState("");
  const [promo, setPromo] = useState("");
  const [openCat, setOpenCat] = useState<string>("ewallet");
  const [selectedPayment, setSelPayment] = useState<{ catId?: string; methodId?: string }>({});

  const selectedVariant = React.useMemo(
    () => product.variants.find((d) => d.id === selectedVariantId),
    [selectedVariantId, product.variants]
  );

  const selectedPaymentMethod = React.useMemo(() => {
    if (!selectedPayment.catId || !selectedPayment.methodId) return null;
    const cat = paymentCategories.find((c) => c.id === selectedPayment.catId);
    return cat?.methods.find((m) => m.id === selectedPayment.methodId) || null;
  }, [selectedPayment, paymentCategories]);

  const fee = React.useMemo(() => {
    if (!selectedPaymentMethod) return 0;
    const subtotal = (selectedVariant?.price || 0) * qty;
    return Math.round(
      (selectedPaymentMethod.fee.flat || 0) + (subtotal * (selectedPaymentMethod.fee.percent || 0)) / 100
    );
  }, [selectedPaymentMethod, selectedVariant, qty]);

  const subtotal = (selectedVariant?.price || 0) * qty;
  const grandTotal = Math.max(0, subtotal + fee);

  const isUidValid = RE_WZM_UID.test(uid.trim());
  const isReady = Boolean(isUidValid && selectedVariant && selectedPaymentMethod);

  function validate(): string | null {
    if (!uid.trim()) return "Activision ID (UID) wajib diisi.";
    if (!isUidValid) return "Activision ID harus angka 6–16 digit.";
    if (!selectedVariant) return "Pilih nominal terlebih dahulu.";
    if (!selectedPaymentMethod) return "Pilih metode pembayaran.";
    return null;
  }

  function handleOrder() {
    const err = validate();
    if (err) {
      showToast(err, "error");
      return;
    }
    if (selectedVariant && selectedPaymentMethod) {
      const checkoutData: CheckoutData = {
        product,
        variant: selectedVariant,
        quantity: qty,
        formValues: {
          uid,                 // WZM pakai Activision ID (UID)
          server: nickname || "", // taruh Nickname opsional pada field "server" agar payload kompatibel
          email,
          wa,
          promo,
        },
        selectedPaymentMethod: selectedPaymentMethod,
      };
      onProceedToCheckout(checkoutData);
    }
  }

  const bannerSrc = warzoneProductPageBannerUrl || mlProductPageBannerUrl;

  return (
    <>
      <main className="max-w-screen-md mx-auto px-4 pb-[160px]">
        {/* Hero */}
        <section>
          <div className="w-full aspect-[1920/749] rounded-2xl bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] overflow-hidden translate-y-[5%]">
            <img src={bannerSrc} alt="Warzone Mobile Banner" className="w-full h-full object-cover rounded-2xl" />
          </div>

          <div className="mt-3 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-700 rounded-xl overflow-hidden">
                <img src={product.image} alt={product.name || "Warzone Mobile"} className="w-full h-full object-cover" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">CALL OF DUTY: WARZONE MOBILE</h2>
                <p className="text-gray-400 text-sm">{product.brand || "Activision"}</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-sm font-medium text-gray-300">
              <div className="flex items-center gap-2">⚡ Proses Cepat</div>
              <div className="flex items-center gap-2">💬 Chat 24/7</div>
              <div className="flex items-center gap-2">🔒 Pembayaran Aman</div>
            </div>
          </div>
        </section>

        {/* Tabs */}
        <div className="mt-4 flex gap-2">
          <button
            onClick={() => setTab("trx")}
            className={`flex-1 h-10 rounded-full font-semibold ${
              tab === "trx"
                ? "text-white bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)]"
                : "bg-gray-800 border border-gray-700 text-gray-300"
            }`}
          >
            Transaksi
          </button>
          <button
            onClick={() => setTab("info")}
            className={`flex-1 h-10 rounded-full font-semibold ${
              tab === "info"
                ? "text-white bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)]"
                : "bg-gray-800 border border-gray-700 text-gray-300"
            }`}
          >
            Keterangan
          </button>
        </div>

        {tab === "trx" ? (
          <>
            {/* Step 1: UID + Nickname */}
            <section className="mt-4 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">1 • Masukkan Activision ID (Nickname opsional)</h3>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-1">
                  <label className="text-sm text-gray-400">Activision ID (UID)</label>
                  <input
                    value={uid}
                    onChange={(e) => setUid(e.target.value.replace(/\D/g, "").slice(0, 16))}
                    onBlur={() => { if (uid && !isUidValid) showToast("Activision ID harus angka 6–16 digit.", "error"); }}
                    placeholder="Contoh: 1234567890"
                    inputMode="numeric"
                    pattern="\d*"
                    maxLength={16}
                    className="mt-1 w-full h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]"
                  />
                  <p className="text-xs text-gray-400 mt-2">
                    Cara cek UID: buka game → profil → Basic Info → lihat User ID.
                  </p>
                </div>
                <div className="sm:col-span-1">
                  <label className="text-sm text-gray-400">Nickname (opsional)</label>
                  <input
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value.slice(0, 30))}
                    placeholder="Contoh: NexusPlayer#1234567"
                    maxLength={30}
                    className="mt-1 w-full h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]"
                  />
                </div>
              </div>
            </section>
            
            {/* Step 2: Nominal CP/Bundle/Pass */}
            <section className="mt-4 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">2 • Pilih Nominal (CP / Bundle / Pass)</h3>
              <div className="mt-3 grid grid-cols-2 gap-3">
                {product.variants.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setSelectedVariantId(d.id)}
                    className={`text-left p-3 rounded-xl border-2 ${selectedVariantId===d.id ? "border-[#7F1DFF] ring-2 ring-[#38BDF8]/40 bg-purple-900/30" : "border-gray-700 bg-gray-700"}`}
                  >
                    <div className="font-semibold text-sm text-white">{d.label}</div>
                    <div className="text-[#38BDF8] font-bold mt-1">{currency(d.price)}</div>
                    {d.strike ? <div className="text-red-500 line-through text-xs">{currency(d.strike)}</div> : null}
                  </button>
                ))}
              </div>
            </section>
          </>
        ) : (
          <div className="space-y-4">
            <section className="mt-4 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">Deskripsi Warzone Mobile</h3>
              <p className="mt-2 text-gray-300">
                Top up CP Warzone Mobile cepat, aman, dan resmi di {APP_NAME}. Pilih nominal, masukkan Activision ID,
                pilih metode pembayaran, lalu pesan.
              </p>
            </section>
          </div>
        )}
      </main>

      <div className="fixed left-0 right-0" style={{ bottom: TABBAR_H }}>
        <div className="mx-auto max-w-screen-md px-4">
          <div className="rounded-t-2xl bg-gray-800/90 backdrop-blur shadow-[0_-5px_24px_rgba(0,0,0,0.08)] p-3 border-t border-x border-gray-700">
            <div className="text-sm text-gray-400 border border-dashed border-gray-700 rounded-xl p-3">
              {selectedVariant ? (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span>Item: <b className="text-white">{selectedVariant.label}</b> × {qty}</span>
                  <span>Total: <b className="text-white">{currency(grandTotal)}</b></span>
                </div>
              ) : (
                "Belum ada item produk yang dipilih."
              )}
            </div>
            <button
              onClick={handleOrder}
              disabled={!isReady}
              className="mt-3 w-full h-14 rounded-full text-white font-semibold bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)] shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              🛍️ Pesan Sekarang!
            </button>
          </div>
        </div>
      </div>
    </>
  );
}