import React, { useState, useCallback } from "react";
import { CheckoutData, PaymentCategory, ProductDetail, ProductVariant, FormField } from "../types.ts";
import { ChevronLeftIcon, ShareIcon, ChatBubbleLeftEllipsisIcon, StarIcon, ChevronDownIcon, ShoppingBagIcon } from './icons/index.tsx';

interface UnifiedProductPageProps {
  product: ProductDetail;
  paymentCategories: PaymentCategory[];
  onProceedToCheckout: (data: CheckoutData) => void;
  showToast: (message: string, type: "success" | "error") => void;
  onBack: () => void;
}

const APP_NAME = "NexusTOPUP";

function currency(n: number) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
}

export default function UnifiedProductPage({
  product,
  paymentCategories,
  onProceedToCheckout,
  showToast,
  onBack,
}: UnifiedProductPageProps) {
  const [tab, setTab] = useState<"trx" | "info">("trx");
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(product.variants.find(v => v.bestValue)?.id || product.variants[0]?.id || null);
  const [qty, setQty] = useState(1);
  const [openCat, setOpenCat] = useState<string>("ewallet");
  const [selectedPayment, setSelPayment] = useState<{ catId?: string; methodId?: string }>({});

  const selectedVariant = React.useMemo(() => product.variants.find(v => v.id === selectedVariantId), [selectedVariantId, product.variants]);

  const selectedPaymentMethod = React.useMemo(() => {
    if (!selectedPayment.catId || !selectedPayment.methodId) return null;
    const cat = paymentCategories.find(c => c.id === selectedPayment.catId);
    return cat?.methods.find(m => m.id === selectedPayment.methodId) || null;
  }, [selectedPayment, paymentCategories]);

  const grandTotal = React.useMemo(() => {
    const subtotal = (selectedVariant?.price || 0) * qty;
    if (!selectedPaymentMethod) return subtotal;
    
    const fee = Math.round((selectedPaymentMethod.fee.flat || 0) + subtotal * (selectedPaymentMethod.fee.percent || 0) / 100);
    return Math.max(0, subtotal + fee);
  }, [selectedPaymentMethod, selectedVariant, qty]);

  const validate = useCallback(() => {
    const errors: Record<string, string> = {};
    let isValid = true;
    for (const field of product.fields) {
        const value = formValues[field.id] || '';
        if (field.required && !value.trim()) {
            errors[field.id] = `${field.label} wajib diisi.`;
            isValid = false;
        } else if (value && field.validationRegex && !new RegExp(field.validationRegex).test(value)) {
            errors[field.id] = field.validationMessage || `Format ${field.label} tidak valid.`;
            isValid = false;
        }
    }
    if (!selectedVariant) {
        showToast("Pilih nominal terlebih dahulu.", "error");
        isValid = false;
    }
    if (!selectedPaymentMethod) {
        showToast("Pilih metode pembayaran.", "error");
        isValid = false;
    }
    setFormErrors(errors);
    return isValid;
  }, [product.fields, formValues, selectedVariant, selectedPaymentMethod, showToast]);

  const handleOrder = () => {
    if (!validate()) {
      return;
    }
    
    if (selectedVariant && selectedPaymentMethod) {
        const checkoutData: CheckoutData = {
          product,
          variant: selectedVariant,
          quantity: qty,
          formValues: {
            ...formValues,
          },
          selectedPaymentMethod,
        };
        onProceedToCheckout(checkoutData);
    }
  };

  const handleInputChange = (fieldId: string, value: string) => {
    const field = product.fields.find(f => f.id === fieldId);
    const sanitizedValue = field?.sanitizer ? field.sanitizer(value) : value;
    setFormValues(prev => ({ ...prev, [fieldId]: sanitizedValue }));
    if (formErrors[fieldId]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[fieldId];
        return newErrors;
      });
    }
  };

  return (
    <>
      <div className="max-w-screen-md mx-auto px-4 w-full pb-[160px]">
        {/* Hero */}
        <section>
          <div className="w-full aspect-[1920/749] rounded-2xl bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] overflow-hidden translate-y-[5%]">
            {product.bannerUrl && <img src={product.bannerUrl} alt={`${product.name} Banner`} className="w-full h-full object-cover rounded-2xl"/>}
          </div>

          <div className="mt-3 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-700 rounded-xl overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover"/>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">{product.name}</h2>
                <p className="text-gray-400 text-sm">{product.brand}</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-sm font-medium text-gray-300">
              <div className="flex items-center gap-2">⚡ Proses Cepat</div>
              <div className="flex items-center gap-2">💬 Chat 24/7</div>
              <div className="flex items-center gap-2">🔒 Pembayaran Aman</div>
            </div>
          </div>
        </section>

        {/* Tabs */}
        <div className="mt-4 flex gap-2">
          <button onClick={() => setTab("trx")}
            className={`flex-1 h-10 rounded-full font-semibold ${tab==="trx" ? "text-white bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)]" : "bg-gray-800 border border-gray-700 text-gray-300"}`}>
            Transaksi
          </button>
          <button onClick={() => setTab("info")}
            className={`flex-1 h-10 rounded-full font-semibold ${tab==="info" ? "text-white bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)]" : "bg-gray-800 border border-gray-700 text-gray-300"}`}>
            Keterangan
          </button>
        </div>

        {tab==="trx" ? (
          <div className="space-y-4">
            {/* Step 1: Dynamic Form */}
            <section className="mt-4 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">1 • Lengkapi Data</h3>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {product.fields.map(field => (
                  <div key={field.id} className="sm:col-span-1">
                    <label className="text-sm text-gray-400">{field.label}</label>
                    {field.type === 'select' ? (
                        <select
                          value={formValues[field.id] || ''}
                          onChange={(e) => handleInputChange(field.id, e.target.value)}
                          className="mt-1 w-full h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]"
                        >
                          <option value="" disabled>{field.placeholder || `Pilih ${field.label}`}</option>
                          {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    ) : (
                        <input
                          type={field.type}
                          inputMode={field.inputMode}
                          value={formValues[field.id] || ''}
                          onChange={(e) => handleInputChange(field.id, e.target.value)}
                          placeholder={field.placeholder}
                          className="mt-1 w-full h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]"
                        />
                    )}
                    {field.helper && <p className="text-xs text-gray-400 mt-2">{field.helper}</p>}
                    {formErrors[field.id] && <p className="text-xs text-red-400 mt-1">{formErrors[field.id]}</p>}
                  </div>
                ))}
              </div>
            </section>
            
            {/* Other Steps */}
            <section className="p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">2 • Pilih Nominal</h3>
              <div className="mt-3 grid grid-cols-2 gap-3">
                {product.variants.map(d => (
                  <button key={d.id} onClick={()=>setSelectedVariantId(d.id)}
                    className={`text-left p-3 rounded-xl border-2 ${selectedVariantId===d.id ? "border-[#7F1DFF] ring-2 ring-[#38BDF8]/40 bg-purple-900/30" : "border-gray-700 bg-gray-700"}`}>
                    <div className="font-semibold text-sm text-white">{d.label}</div>
                    <div className="text-[#38BDF8] font-bold mt-1">{currency(d.price)}</div>
                    {d.strike ? <div className="text-red-500 line-through text-xs">{currency(d.strike)}</div> : null}
                  </button>
                ))}
              </div>
            </section>

            <section className="p-4 bg-gray-800 border border-gray-700 rounded-2xl">
                <h3 className="font-bold text-white">3 • Pilih Pembayaran</h3>
                <div className="mt-2 space-y-2">
                    {paymentCategories.map(cat => (
                        <div key={cat.id} className="border border-gray-700 rounded-xl overflow-hidden">
                            <button onClick={() => setOpenCat(v => v === cat.id ? "" : cat.id)}
                                className="w-full h-12 px-3 text-left font-semibold bg-gray-700/50 text-white flex justify-between items-center">
                                <span>{cat.name}</span>
                                <ChevronDownIcon className={`w-5 h-5 text-white transition-transform ${openCat === cat.id ? 'rotate-180' : ''}`} />
                            </button>
                            {openCat === cat.id && (
                                <div className="p-3">
                                    <div className="space-y-2">
                                        {cat.methods.map(m => {
                                            const isSelected = selectedPayment.catId === cat.id && selectedPayment.methodId === m.id;
                                            const feeText = m.fee.flat > 0 ? (m.fee.percent > 0 ? `${currency(m.fee.flat)} + ${m.fee.percent}%` : currency(m.fee.flat)) : (m.fee.percent > 0 ? `${m.fee.percent}%` : "Gratis");
                                            return (
                                                <button key={m.id}
                                                    onClick={() => setSelPayment({ catId: cat.id, methodId: m.id })}
                                                    className={`w-full flex justify-between items-center p-3 rounded-xl border-2 transition-all ${isSelected ? "border-[#7F1DFF] bg-purple-900/50" : "border-transparent bg-gray-700 hover:bg-gray-600"}`}>
                                                    <span className="font-semibold text-sm text-white">{m.name}</span>
                                                    <span className="text-xs font-medium text-gray-400">Biaya: {feeText}</span>
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </section>

             <section className="p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white">4 • Detail Kontak (Opsional)</h3>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-sm text-gray-400">Email</label>
                  <input type="email" value={formValues.email || ''} onChange={e=>handleInputChange('email', e.target.value)}
                    placeholder="example@gmail.com"
                    className="mt-1 w-full h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]" />
                </div>
                <div>
                  <label className="text-sm text-gray-400">No. WhatsApp</label>
                  <div className="mt-1 flex gap-2">
                    <div className="h-11 px-3 rounded-xl border border-gray-700 flex items-center bg-gray-800 text-white">+62</div>
                    <input type="tel" value={formValues.wa || ''} onChange={e=>handleInputChange('wa', e.target.value.replace(/\D/g, ''))}
                      placeholder="81234567890"
                      className="flex-1 h-11 rounded-xl border border-gray-700 bg-gray-900 text-white px-3 outline-none focus:ring-2 focus:ring-[#38BDF8]" />
                  </div>
                </div>
              </div>
            </section>
          </div>
        ) : (
          <div className="space-y-4">
            {product.descriptionTab && (
              <section className="mt-4 p-4 bg-gray-800 border border-gray-700 rounded-2xl">
                <h3 className="font-bold text-white">{product.descriptionTab.title}</h3>
                <p className="mt-2 text-gray-300">{product.descriptionTab.content}</p>
                <ol className="mt-3 list-decimal list-inside space-y-1 text-gray-300">
                  {product.descriptionTab.steps.map((step, i) => <li key={i}>{step}</li>)}
                </ol>
              </section>
            )}
            
            <section className="p-4 bg-gray-800 border border-gray-700 rounded-2xl">
              <h3 className="font-bold text-white text-lg">Rating & Ulasan ({product.reviewsCount.toLocaleString()})</h3>
              <div className="mt-3 flex items-center gap-4">
                <div className="text-center">
                  <p className="text-4xl font-extrabold text-white">{product.rating.toFixed(2)}<span className="text-xl text-gray-400">/5</span></p>
                  <div className="flex justify-center mt-1">
                    {[...Array(5)].map((_, i) => <StarIcon key={i} className={`w-5 h-5 ${i < Math.round(product.rating) ? 'text-yellow-400' : 'text-gray-600'}`} />)}
                  </div>
                </div>
                <div className="flex-1 space-y-1">
                  {[5, 4, 3, 2, 1].map(star => (
                    <div key={star} className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 flex items-center">{star}<StarIcon className="w-3 h-3 text-yellow-400 ml-0.5"/></span>
                      <div className="w-full bg-gray-600 rounded-full h-1.5">
                        <div className="bg-yellow-400 h-1.5 rounded-full" style={{ width: `${(star/5)*80 + Math.random()*20}%`}}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}
      </div>

      <div className="fixed left-0 right-0 bottom-[72px] md:bottom-auto md:relative">
        <div className="mx-auto max-w-screen-md px-4">
          <div className="rounded-t-2xl bg-gray-800/90 backdrop-blur shadow-[0_-5px_24px_rgba(0,0,0,0.08)] p-3 border-t border-x border-gray-700 md:rounded-b-2xl md:border-b md:shadow-none">
            <div className="text-sm text-gray-400 border border-dashed border-gray-700 rounded-xl p-3">
              {selectedVariant ? (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span>Item: <b className="text-white">{selectedVariant.label}</b> × {qty}</span>
                  <span>Total: <b className="text-white">{currency(grandTotal)}</b></span>
                </div>
              ) : (
                "Belum ada item produk yang dipilih."
              )}
            </div>
            <div className="mt-3 flex items-center space-x-2">
                <button
                onClick={handleOrder}
                disabled={!selectedVariant || !selectedPaymentMethod || Object.keys(formErrors).length > 0}
                className="w-full h-14 rounded-full text-white font-semibold bg-[linear-gradient(135deg,#7F1DFF,#38BDF8)] shadow-md disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                <ShoppingBagIcon className="w-6 h-6" />
                <span>Pesan Sekarang!</span>
                </button>
                <button className="flex-shrink-0 w-14 h-14 rounded-full bg-gradient-to-br from-[#38BDF8] to-[#7F1DFF] text-white flex items-center justify-center shadow-lg">
                    <ChatBubbleLeftEllipsisIcon className="w-7 h-7" />
                </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}