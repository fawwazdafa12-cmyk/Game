import React, { useEffect, useState } from 'react';
import { CheckCircleIcon, ExclamationTriangleIcon } from './icons/index.tsx';

interface ToastProps {
  message?: string;
  type?: 'success' | 'error';
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (message) {
      setIsVisible(true);
      const timer = setTimeout(() => {
        setIsVisible(false);
        // Allow fade-out animation to complete before calling onClose
        setTimeout(() => {
            onClose();
        }, 300);
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [message, onClose]);

  if (!message || !type) return null;

  const isSuccess = type === 'success';
  const bgColor = isSuccess ? 'bg-green-800' : 'bg-red-800';
  const textColor = isSuccess ? 'text-green-100' : 'text-red-100';
  const Icon = isSuccess ? CheckCircleIcon : ExclamationTriangleIcon;

  return (
    <div
      className={`fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-2rem)] max-w-sm p-4 rounded-xl shadow-lg ${bgColor} ${textColor} flex items-center space-x-3 transition-all duration-300 ease-out
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`
      }
      role="alert"
    >
      <Icon className="w-6 h-6 flex-shrink-0" />
      <span className="font-semibold text-sm">{message}</span>
    </div>
  );
};

export default Toast;