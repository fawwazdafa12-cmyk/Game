

import React from 'react';
import { TransactionDetail, TransactionStatus } from '../types.ts';
import {
    ChevronLeftIcon,
    ShareIcon,
    ChatBubbleLeftEllipsisIcon,
    CheckCircleIcon,
    ClockIcon,
    ExclamationCircleIcon,
    InformationCircleIcon,
    ClipboardDocumentIcon,
    ArrowDownTrayIcon
} from './icons/index.tsx';
import CheckoutActionBar from './CheckoutActionBar.tsx';
// FIX: Changed formatDateOnly to formatDateOnlyShort as it is the exported member.
import { formatDateTimeShort, formatDateOnlyShort } from '../src/lib/time.ts';
import { useCountdown } from '../src/hooks/useCountdown.ts';

interface TransactionDetailPageProps {
    transaction: TransactionDetail;
    onBack: () => void;
    showToast: (message: string, type: 'success' | 'error') => void;
}

const statusConfig: Record<TransactionStatus, {
    bgColor: string,
    textColor: string,
    Icon: React.FC<{className?: string}>
}> = {
    'Berhasil': { bgColor: 'bg-green-100', textColor: 'text-green-700', Icon: CheckCircleIcon },
    'Diproses': { bgColor: 'bg-sky-100', textColor: 'text-[#38BDF8]', Icon: InformationCircleIcon },
    'Menunggu Bayar': { bgColor: 'bg-orange-100', textColor: 'text-orange-500', Icon: ClockIcon },
    'Dibatalkan': { bgColor: 'bg-red-100', textColor: 'text-red-500', Icon: ExclamationCircleIcon },
};

const DetailRow: React.FC<{ label: string; value: string | number; canCopy?: boolean; valueClass?: string }> = ({ label, value, canCopy = false, valueClass = "font-bold text-white" }) => (
    <div className="flex justify-between items-center text-sm">
        <span className="text-gray-400">{label}</span>
        <div className="flex items-center space-x-2">
            <span className={valueClass}>{typeof value === 'number' ? `Rp${value.toLocaleString('id-ID')}` : value}</span>
            {canCopy && (
                <button onClick={() => navigator.clipboard.writeText(String(value))} className="text-white hover:text-[#7F1DFF]">
                    <ClipboardDocumentIcon className="w-4 h-4" />
                </button>
            )}
        </div>
    </div>
);

const SectionCard: React.FC<{ title: string; children: React.ReactNode; }> = ({ title, children }) => (
    <div className="bg-gray-800 border border-gray-700 rounded-xl">
        <h3 className="font-bold text-white p-4 border-b border-gray-700">{title}</h3>
        <div className="p-4 space-y-3">
            {children}
        </div>
    </div>
);

const CountdownTimer: React.FC<{ expiryDate: string }> = ({ expiryDate }) => {
    const { hours, minutes, seconds, isExpired } = useCountdown(expiryDate);
    
    const formatTime = (time: number) => time.toString().padStart(2, '0');
    
    if (isExpired) {
        return <span className="text-lg font-bold text-red-500">Expired</span>;
    }

    return (
        <div className="text-2xl font-bold text-white tracking-widest">
            <span>{formatTime(hours)}</span>:<span>{formatTime(minutes)}</span>:<span>{formatTime(seconds)}</span>
        </div>
    );
};

const TransactionDetailPage: React.FC<TransactionDetailPageProps> = ({ transaction, onBack, showToast }) => {
    const { status, rincianBiaya, paymentDetails, productDetails, deliveryDetails, activityLogs, coinsUsed, coinsEarned } = transaction;
    const config = statusConfig[status];
    const totalPayment = rincianBiaya.total - (coinsUsed || 0);

    const handlePayNow = () => {
        // Simulate payment process
        showToast(`Pembayaran untuk ${transaction.id} berhasil diproses.`, 'success');
        // Here you would typically navigate to a success page or update the transaction status
    };

    return (
        <div className="pt-16 md:pt-20 bg-gray-900 min-h-screen">
            <header className="fixed top-0 left-0 right-0 z-50 bg-gray-800 h-16 md:h-20 border-b border-gray-700">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-full relative">
                    <button onClick={onBack} className="absolute left-4 p-2 rounded-full hover:bg-gray-700">
                        <ChevronLeftIcon className="w-6 h-6 text-white" />
                    </button>
                    <h1 className="text-xl font-bold text-white text-center w-full">Detail Transaksi</h1>
                    <div className="absolute right-4 flex space-x-2">
                        <button className="p-2 rounded-full hover:bg-gray-700"><ShareIcon className="w-6 h-6 text-white" /></button>
                        <button className="p-2 rounded-full hover:bg-gray-700"><ChatBubbleLeftEllipsisIcon className="w-6 h-6 text-white" /></button>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto p-4 space-y-4 pb-44">
                {/* Status Banner */}
                <div className={`rounded-xl p-4 flex items-center space-x-3 ${config.bgColor} ${config.textColor}`}>
                    <config.Icon className="w-8 h-8 flex-shrink-0" />
                    <div>
                        <h2 className="font-extrabold text-lg">{status.replace(' ', '... ')}</h2>
                        <p className="text-xs">{transaction.id} &bull; {formatDateOnlyShort(transaction.dateTime)}</p>
                    </div>
                </div>

                {/* Ringkasan Pesanan */}
                 <SectionCard title="Ringkasan Pesanan">
                    <DetailRow label="ID Pesanan" value={transaction.id} canCopy />
                    <DetailRow label="Tanggal Transaksi" value={formatDateTimeShort(transaction.dateTime)} />
                    <hr className="!my-4 border-gray-700" />
                    <div className="space-y-2">
                        <DetailRow label="Harga Produk" value={rincianBiaya.hargaProduk} />
                        <DetailRow label="Biaya Admin" value={rincianBiaya.biayaAdmin} />
                        {rincianBiaya.diskon > 0 && <DetailRow label="Diskon" value={-rincianBiaya.diskon} />}
                        {coinsUsed && coinsUsed > 0 && <DetailRow label="Koin digunakan" value={`-${coinsUsed.toLocaleString('id-ID')} NX`} valueClass="font-bold text-red-500" />}
                    </div>
                    <hr className="!my-4 border-gray-700" />
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-white">Total Pembayaran</span>
                        <span className="font-extrabold text-xl text-[#7F1DFF]">Rp{totalPayment.toLocaleString('id-ID')}</span>
                    </div>
                     {coinsEarned && coinsEarned > 0 && (
                        <div className="mt-3 text-center text-xs p-2 bg-green-900/50 rounded-md text-green-300 font-semibold">
                            Kamu akan mendapatkan +{coinsEarned.toLocaleString('id-ID')} Nexus Coins dari transaksi ini.
                        </div>
                    )}
                 </SectionCard>
                 
                 {/* Detail Produk */}
                 <SectionCard title="Detail Produk">
                    <div className="flex items-center space-x-4">
                        <img src={productDetails.imageUrl} alt={productDetails.name} className="w-16 h-16 rounded-lg object-cover" />
                        <div className="flex-1">
                            <p className="font-bold text-white">{productDetails.name}</p>
                            <p className="text-sm text-gray-400">{productDetails.item}</p>
                        </div>
                         <button className="px-4 py-1.5 border-2 border-[#7F1DFF] text-white text-sm font-bold rounded-full hover:bg-purple-500/10 transition-colors whitespace-nowrap">
                            Beli Lagi
                        </button>
                    </div>
                 </SectionCard>

                 {/* Detail Akun */}
                 <SectionCard title="Detail Akun Top Up">
                    <DetailRow label="Nickname" value={deliveryDetails.nickname} canCopy />
                    <DetailRow label="UID" value={`${deliveryDetails.uid} (${deliveryDetails.server})`} canCopy />
                 </SectionCard>
                 
                 {/* Metode Pembayaran */}
                 <SectionCard title="Metode Pembayaran">
                    <DetailRow label="Metode" value={paymentDetails.channel} />
                    <div className="p-4 bg-gray-700 rounded-lg text-center space-y-2">
                        <p className="text-sm text-gray-400">Nomor Virtual Account</p>
                        <p className="text-2xl font-extrabold tracking-wider text-white">{paymentDetails.code}</p>
                    </div>
                     {status === 'Menunggu Bayar' && (
                        <div className="flex items-center justify-between text-sm">
                            <span className="text-orange-500 font-bold">Batas Waktu Pembayaran</span>
                            <CountdownTimer expiryDate={paymentDetails.expireAt} />
                        </div>
                    )}
                 </SectionCard>

                {/* Riwayat Aktivitas */}
                <SectionCard title="Riwayat Aktivitas">
                    <div className="space-y-3">
                        {activityLogs.map((log, index) => (
                            <div key={index} className="flex items-start space-x-3 text-sm">
                                <div className="w-5 h-5 flex-shrink-0 bg-green-500 rounded-full border-4 border-green-900 mt-0.5"></div>
                                <div>
                                    <p className="font-bold text-white">{log.label}</p>
                                    <p className="text-xs text-gray-400">{formatDateTimeShort(log.timestamp)}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </SectionCard>
            </main>
            
            {status === 'Menunggu Bayar' && (
                <CheckoutActionBar
                    total={totalPayment}
                    buttonText="Bayar Sekarang"
                    onClick={handlePayNow}
                    disabled={false}
                    showBottomNavBar={true}
                />
            )}
        </div>
    );
};

export default TransactionDetailPage;