
// This file is deprecated. All image assets have been moved to `ImageAssets.ts`.
// It is kept temporarily to avoid breaking imports in a large project but can be safely removed
// once all components have been updated to import from `ImageAssets.ts`.
