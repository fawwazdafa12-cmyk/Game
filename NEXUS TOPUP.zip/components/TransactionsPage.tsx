

import React, { useState } from 'react';
import { ReceiptSolidIcon, SearchIcon } from './icons/index.tsx';
import { Transaction, TransactionStatus, TransactionDetail } from '../types.ts';
import { formatDateTimeShort } from '../src/lib/time.ts';

const statusStyles: Record<TransactionStatus, string> = {
  'Berhasil': 'bg-green-100 text-green-700',
  'Diproses': 'bg-sky-100 text-[#38BDF8]',
  'Menunggu Bayar': 'bg-orange-100 text-orange-500',
  'Dibatalkan': 'bg-red-100 text-red-500',
};

const TransactionCard: React.FC<{ transaction: Transaction; onViewDetail: (id: string) => void }> = ({ transaction, onViewDetail }) => (
  <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 space-y-3">
    <div className="flex justify-between items-center pb-3 border-b border-gray-700">
      <span className="text-sm font-bold text-white">{transaction.id}</span>
      <span className={`px-2 py-1 text-xs font-bold rounded-full ${statusStyles[transaction.status]}`}>{transaction.status}</span>
    </div>
    <div className="text-sm text-gray-400 space-y-1">
      <p><span className="font-bold text-white">{transaction.productName}</span></p>
      <p>ID Akun: {transaction.gameAccountId}</p>
      <p>Pembayaran: {transaction.paymentMethod}</p>
      <p>{formatDateTimeShort(transaction.dateTime)}</p>
    </div>
    <div className="flex justify-between items-center pt-3 border-t border-gray-700">
        <div>
            <span className="text-sm text-gray-400">Total</span>
            <p className="font-bold text-lg text-white">Rp{transaction.total.toLocaleString('id-ID')}</p>
        </div>
        {transaction.status === 'Menunggu Bayar' ? (
             <div className="flex space-x-2">
                <button onClick={() => onViewDetail(transaction.id)} className="px-4 py-2 text-sm font-bold border-2 border-gray-600 text-gray-300 rounded-full hover:border-[#7F1DFF] transition-colors">Lihat Detail</button>
                <button onClick={() => onViewDetail(transaction.id)} className="px-4 py-2 text-sm font-bold bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] text-white rounded-full hover:brightness-110 transition-all">Bayar Sekarang</button>
            </div>
        ) : (
            <button onClick={() => onViewDetail(transaction.id)} className="px-4 py-2 text-sm font-bold border-2 border-[#7F1DFF] text-white rounded-full hover:bg-purple-500/10 transition-colors">Lihat Detail</button>
        )}
    </div>
  </div>
);

const EmptyState: React.FC = () => (
    <div className="text-center py-16 px-4">
        <div className="mx-auto w-24 h-24 flex items-center justify-center bg-gray-800 rounded-full mb-4">
            <ReceiptSolidIcon className="w-12 h-12 text-white" />
        </div>
        <h3 className="text-xl font-bold text-white">Belum ada transaksi</h3>
        <p className="text-gray-400 mt-2 mb-6">Semua transaksimu akan muncul di sini.</p>
        <button className="px-6 py-3 font-bold bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] text-white rounded-full hover:brightness-110 transition-all">Mulai Top Up</button>
    </div>
);

interface TransactionsPageProps {
  transactions: TransactionDetail[];
  onViewDetail: (id: string) => void;
}

const TransactionsPage: React.FC<TransactionsPageProps> = ({ transactions, onViewDetail }) => {
  const [activeFilter, setActiveFilter] = useState<TransactionStatus | 'Semua'>('Semua');
  const [searchQuery, setSearchQuery] = useState('');

  const filters: (TransactionStatus | 'Semua')[] = ['Semua', 'Berhasil', 'Diproses', 'Menunggu Bayar', 'Dibatalkan'];

  const filteredTransactions = React.useMemo(() => {
    return transactions
      .filter(tx => activeFilter === 'Semua' || tx.status === activeFilter)
      .filter(tx => 
        tx.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.productName.toLowerCase().includes(searchQuery.toLowerCase())
      );
  }, [activeFilter, searchQuery, transactions]);

  return (
    <div className="pt-16 md:pt-20 bg-gray-900 min-h-screen">
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-800 border-b border-gray-700 h-16 md:h-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-full justify-center">
          <h1 className="text-xl font-bold text-white">Transaksi Saya</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
        <p className="text-sm text-gray-400">Riwayat transaksi di NexusTOPUP</p>

        {/* Search Input */}
        <div className="relative">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white" />
            <input 
                type="text"
                placeholder="Cari ID Pesanan / Game / Produk"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-12 pl-11 pr-4 bg-gray-800 border border-gray-700 text-white rounded-full focus:ring-2 focus:ring-[#38BDF8] focus:outline-none"
            />
        </div>

        {/* Filter Chips */}
        <div className="flex space-x-2 overflow-x-auto pb-2 -mx-4 px-4 no-scrollbar">
            {filters.map(filter => (
                 <button
                    key={filter}
                    onClick={() => setActiveFilter(filter)}
                    className={`flex-shrink-0 px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-300 border whitespace-nowrap
                        ${activeFilter === filter ? 'bg-gradient-to-r from-[#7F1DFF] to-[#38BDF8] text-white border-transparent' : 'bg-gray-800 text-gray-300 border-gray-700 hover:border-gray-500'}`
                    }
                >
                    {filter}
                </button>
            ))}
        </div>

        {/* Transaction List */}
        <div className="space-y-4 pb-24">
            {filteredTransactions.length > 0 ? (
                filteredTransactions.map(tx => <TransactionCard key={tx.id} transaction={tx} onViewDetail={onViewDetail} />)
            ) : (
                <EmptyState />
            )}
        </div>
      </main>
    </div>
  );
};

export default TransactionsPage;