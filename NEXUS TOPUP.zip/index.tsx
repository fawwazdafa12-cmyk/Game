
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './components/App.tsx';
import SentryErrorBoundary from './components/SentryErrorBoundary.tsx';
import { ObservabilityProvider } from './src/lib/obs/ObservabilityContext.tsx';
import { initSentry } from './src/lib/obs/sentry.client.ts';
import { I18nProvider } from './src/lib/i18n/I18nContext.tsx';

// Initialize observability tools
// In a real app, SENTRY_DSN would come from environment variables.
initSentry();

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <SentryErrorBoundary>
      <ObservabilityProvider>
        <I18nProvider>
          <App />
        </I18nProvider>
      </ObservabilityProvider>
    </SentryErrorBoundary>
  </React.StrictMode>
);