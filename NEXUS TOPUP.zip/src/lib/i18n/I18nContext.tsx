import React, { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';

type Translations = Record<string, any>;
type Locale = 'id' | 'en';

// Simple deep key access utility
const get = (obj: any, path: string): string => {
    if (!obj) return '';
    return path.split('.').reduce((acc, part) => acc && acc[part], obj);
}

interface II18nContext {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<II18nContext | undefined>(undefined);

export const I18nProvider = ({ children }: { children: ReactNode }) => {
  const [locale, setLocale] = useState<Locale>('id');
  const [translations, setTranslations] = useState<{ id?: Translations; en?: Translations }>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTranslations = async () => {
      try {
        const [idResponse, enResponse] = await Promise.all([
          fetch('/src/locales/id.json'),
          fetch('/src/locales/en.json')
        ]);
        if (!idResponse.ok || !enResponse.ok) {
            throw new Error('Failed to fetch translation files');
        }
        const idData = await idResponse.json();
        const enData = await enResponse.json();
        setTranslations({ id: idData, en: enData });
      } catch (error) {
        console.error("Error loading translations:", error);
        // Set empty objects on failure to prevent crashes
        setTranslations({ id: {}, en: {} });
      } finally {
        setIsLoading(false);
      }
    };

    fetchTranslations();
  }, []);

  const t = useCallback((key: string): string => {
    if (isLoading || !translations.id) {
      return key; // Return key as fallback during loading
    }
    const currentTranslations = locale === 'en' ? translations.en : translations.id;
    const fallbackTranslations = translations.id;
    
    const translatedText = get(currentTranslations, key) || get(fallbackTranslations, key) || key;
    return translatedText;
  }, [locale, translations, isLoading]);

  if (isLoading) {
    // Render nothing while translations are loading to prevent
    // the app from rendering with untranslated keys.
    return null;
  }

  return (
    <I18nContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = (): II18nContext => {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};
